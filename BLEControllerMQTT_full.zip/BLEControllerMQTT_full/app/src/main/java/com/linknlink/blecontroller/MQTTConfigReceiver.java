// Receiver updates MQTT broker settings via broadcast
