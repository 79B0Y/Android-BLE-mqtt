// BLEService.java implements BLE scan/connect and MQTT integration
