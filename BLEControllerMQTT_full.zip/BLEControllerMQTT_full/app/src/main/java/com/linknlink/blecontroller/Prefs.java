// Prefs.java placeholder with MQTT config load
