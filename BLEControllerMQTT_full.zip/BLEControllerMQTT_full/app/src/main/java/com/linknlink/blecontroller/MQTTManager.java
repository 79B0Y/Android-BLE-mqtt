// MQTTManager.java placeholder managing publish/subscribe
